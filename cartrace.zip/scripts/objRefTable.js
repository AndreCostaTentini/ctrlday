const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.Car,
		C3.Behaviors.solid,
		C3.Plugins.Keyboard,
		C3.Behaviors.Anchor,
		C3.Plugins.TextBox,
		C3.Plugins.Text,
		C3.Plugins.Sprite.Cnds.OnCollision,
		C3.Plugins.System.Acts.AddVar,
		C3.Plugins.Text.Acts.SetText,
		C3.Plugins.Keyboard.Cnds.IsKeyDown,
		C3.Behaviors.Car.Acts.SimulateControl
	];
};
self.C3_JsPropNameTable = [
	{Sprite: 0},
	{Carro: 0},
	{Sólido: 0},
	{Sprite2: 0},
	{Teclado: 0},
	{Âncora: 0},
	{Sprite3: 0},
	{EntradaDeTexto: 0},
	{Texto: 0},
	{Sprite4: 0},
	{Texto2: 0},
	{Sprite5: 0},
	{Pontos: 0},
	{Pontos2: 0}
];

self.InstanceType = {
	Sprite: class extends self.ISpriteInstance {},
	Sprite2: class extends self.ISpriteInstance {},
	Teclado: class extends self.IInstance {},
	Sprite3: class extends self.ISpriteInstance {},
	EntradaDeTexto: class extends self.ITextInputInstance {},
	Texto: class extends self.ITextInstance {},
	Sprite4: class extends self.ISpriteInstance {},
	Texto2: class extends self.ITextInstance {},
	Sprite5: class extends self.ISpriteInstance {}
}